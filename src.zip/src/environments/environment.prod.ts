export const environment = {
  production: true,
  apiBaseUrl: 'http://localhost:8080',
  authServiceUrl: 'http://localhost:8081'
};
